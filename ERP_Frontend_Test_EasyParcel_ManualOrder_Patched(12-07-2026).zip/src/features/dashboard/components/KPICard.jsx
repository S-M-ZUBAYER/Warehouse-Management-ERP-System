import { Package, Boxes, AlertTriangle, XCircle, ShoppingCart } from "lucide-react";
import productManagementIcon from "../../../assets/sideNavbar/Product_Management.svg";
import outOfStockIcon from "../../../assets/sideNavbar/Out of stock.svg";

// ─────────────────────────────────────────────────────────────────────────────
// KPICard — matches the 4 overview cards in the Figma design
// ─────────────────────────────────────────────────────────────────────────────

const ICONS = {
  package: Package,
  boxes: Boxes,
  cart: ShoppingCart,
  alert: AlertTriangle,
  "x-circle": XCircle,
  "product-management": productManagementIcon,
  "out-of-stock": outOfStockIcon,
};

export default function KPICard({ label, value, icon, color, bg, loading, onClick }) {
  const Icon = ICONS[icon] || Package;
  const isSvgIcon = typeof Icon === "string";
  const isClickable = typeof onClick === "function";

  if (loading) {
    return (
      <div
        className="rounded-2xl p-5 bg-white animate-pulse"
        style={{ border: "1px solid #F1F5F9", minHeight: "110px" }}
      >
        <div className="w-10 h-10 rounded-xl bg-slate-100 mb-4" />
        <div className="h-7 w-24 bg-slate-100 rounded mb-2" />
        <div className="h-3 w-20 bg-slate-100 rounded" />
      </div>
    );
  }

  return (
    <div
      role={isClickable ? "button" : undefined}
      tabIndex={isClickable ? 0 : undefined}
      className={`rounded-2xl p-4 bg-white transition-all duration-200 group ${
        isClickable ? "cursor-pointer" : "cursor-default"
      }`}
      style={{
        border: "1px solid #F1F5F9",
        boxShadow: "0 1px 3px rgba(0,0,0,0.04)",
      }}
      onClick={onClick}
      onKeyDown={(event) => {
        if (!isClickable || (event.key !== "Enter" && event.key !== " ")) return;
        event.preventDefault();
        onClick();
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.boxShadow = "0 4px 16px rgba(0,0,0,0.08)";
        e.currentTarget.style.transform = "translateY(-2px)";
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.boxShadow = "0 1px 3px rgba(0,0,0,0.04)";
        e.currentTarget.style.transform = "";
      }}
    >
      {/* Icon */}
      <div
        className="w-10 h-10 rounded-xl flex items-center justify-center mb-11"
        style={{ background: bg }}
      >
        {isSvgIcon ? (
          <img src={Icon} alt="" aria-hidden="true" className="w-5 h-5" />
        ) : (
          <Icon size={20} color={color} strokeWidth={1.8} />
        )}
      </div>

      {/* Value */}
      <p
        className="text-xl font-display font-bold mb-1 leading-none"
        style={{
          color: "#0F172A",
          letterSpacing: "-0.5px",
        }}
      >
        {value}
      </p>

      {/* Label */}
      <p className="text-xs font-medium font-body" style={{ color: "#94A3B8" }}>
        {label}
      </p>
    </div>
  );
}
