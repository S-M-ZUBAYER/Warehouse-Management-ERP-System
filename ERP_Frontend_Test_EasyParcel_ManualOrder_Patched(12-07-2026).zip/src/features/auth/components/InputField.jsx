import { useTranslation } from "react-i18next";
import { translateStaticText } from "../../../i18nDomTranslator";

export default function InputField({
  icon: Icon,
  label,
  error,
  rightElement,
  className = "",
  ...props
}) {
  const { i18n } = useTranslation();
  const translate = (value) =>
    typeof value === "string"
      ? translateStaticText(value, i18n.resolvedLanguage || i18n.language)
      : value;
  const translatedProps = {
    ...props,
    placeholder: translate(props.placeholder),
    "aria-label": translate(props["aria-label"]),
  };

  return (
    <div className="mb-5">
      {label && (
        <label className="block text-sm font-semibold mb-1.5 text-primary font-body">
          {translate(label)}
        </label>
      )}
      <div className="relative">
        {Icon && (
          <div
            className="absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none flex"
            style={{ color: "#94A3B8" }}
          >
            <Icon size={16} />
          </div>
        )}
        <input
          {...translatedProps}
          className={`w-full font-body rounded-xl text-sm transition-all duration-200 ${className}`}
          style={{
            padding: `12px ${rightElement ? "44px" : "14px"} 12px ${Icon ? "42px" : "14px"}`,
            background: "#F8FAFC",
            border: `1.5px solid ${error ? "#EF4444" : "#CBD5E1"}`,
            color: "#1E293B",
          }}
         onFocus={(e) => {
            e.target.style.borderColor = "#004368";
            e.target.style.boxShadow = "0 0 0 3px rgba(0,67,104,0.12)";
          }}
          onBlur={(e) => {
            e.target.style.borderColor = error ? "#EF4444" : "#CBD5E1";
            e.target.style.boxShadow = "none";
          }}
        />
        {rightElement && (
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 flex">
            {rightElement}
          </div>
        )}
      </div>
      {error && (
        <p className="text-xs mt-1.5 font-medium" style={{ color: "#EF4444" }}>
          {translate(error)}
        </p>
      )}
    </div>
  );
}
