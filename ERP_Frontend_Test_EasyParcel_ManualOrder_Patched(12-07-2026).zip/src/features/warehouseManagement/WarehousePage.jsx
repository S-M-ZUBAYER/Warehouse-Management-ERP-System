import { Plus, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { useWarehouse } from "./hooks/useWarehouse";
import WarehouseTable from "./components/WarehouseTable";
import AddWarehouseModal from "./components/AddWarehouseModal";
import Topbar from "../../components/layout/Topbar";
import RecordDetailModal from "../../components/shared/RecordDetailModal";
import ConfirmActionModal from "../../components/shared/ConfirmActionModal";

// ─────────────────────────────────────────────────────────────────────────────
// WarehousePage — matches Figma image 1 exactly:
//
//   ┌─────────────────────────────────────────────────────────────┐
//   │  [Select Platform ▼] ........................ [+ Add New Warehouse] │  ← dashed blue border card
//   └─────────────────────────────────────────────────────────────┘
//   ┌─────────────────────────────────────────────────────────────┐
//   │  Warehouses List                                             │
//   │  Warehouse Name | Warehouse Attribute | Location | SKU | Default │
//   │  rows...                                                     │
//   └─────────────────────────────────────────────────────────────┘
// ─────────────────────────────────────────────────────────────────────────────

export default function WarehousePage() {
  // const [platformOpen, setPlatformOpen] = useState(false);
  const [detailWarehouse, setDetailWarehouse] = useState(null);
  const [warehouseSearch, setWarehouseSearch] = useState("");

  const {
    warehouses,
    // platform,
    // setPlatform,
    // platforms,
    showModal,
    openModal,
    closeModal,
    form,
    handleFormChange,
    handleAttributeChange,
    errors,
    saving,
    handleAdd,
    toggleDefault,
    editingWarehouse,
    openEditModal,
    deleteModal,
    openDeleteModal,
    closeDeleteModal,
    confirmDelete,
    deleting,
    warehouseLoading,
  } = useWarehouse();

  const visibleWarehouses = useMemo(() => {
    const term = warehouseSearch.trim().toLowerCase();
    if (!term) return warehouses;

    return warehouses.filter((warehouse) =>
      [warehouse.name, warehouse.attribute, warehouse.location]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(term)),
    );
  }, [warehouses, warehouseSearch]);

  return (
    <div className="space-y-5 font-body">
      {/* ── Page Title ── */}
      <Topbar PageTitle="Warehouse Management"></Topbar>
      {/* ── Top filter bar — dashed blue border matching Figma ── */}
      <div className="bg-white rounded-xl px-5 py-4 flex items-end justify-between gap-4">
        {/* <div className="w-64">
          <p className="text-xs font-semibold text-slate-600 mb-1.5">
            Select Platform
          </p>
          <div className="relative">
            <button
              type="button"
              onClick={() => setPlatformOpen((p) => !p)}
              className="w-full flex items-center justify-between gap-2 px-3 py-2 bg-white
                         border border-surface-border rounded-lg text-sm text-left
                         hover:border-primary/40 transition-colors focus:outline-none
                         focus:border-primary"
            >
              <span
                className={
                  platform === "Platform Name Here"
                    ? "text-slate-400"
                    : "text-slate-700"
                }
              >
                {platform}
              </span>
              <ChevronDown
                size={14}
                className={`text-slate-400 flex-shrink-0 transition-transform ${platformOpen ? "rotate-180" : ""}`}
              />
            </button>

            {platformOpen && (
              <div
                className="absolute left-0 top-full mt-1 z-20 bg-white rounded-xl
                           border border-surface-border shadow-lg py-1 min-w-full"
              >
                {platforms.map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => {
                      setPlatform(p);
                      setPlatformOpen(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-sm transition-colors
                      ${
                        platform === p
                          ? "text-primary font-semibold bg-blue-50"
                          : "text-slate-700 hover:bg-surface-card"
                      }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div> */}

        <div className="w-64">
          <p className="text-xs font-semibold text-slate-600 mb-1.5">
            Search Warehouse
          </p>
          <div className="relative">
            <Search
              size={14}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              type="text"
              value={warehouseSearch}
              onChange={(e) => setWarehouseSearch(e.target.value)}
              placeholder="Name, attribute, location"
              className="w-full pl-8 pr-3 py-2 bg-white border border-surface-border rounded-lg
                         text-sm text-slate-700 placeholder-slate-400 outline-none
                         hover:border-primary/40 focus:border-primary transition-colors"
            />
          </div>
        </div>

        {/* Add New Warehouse button */}
        <button
          onClick={openModal}
          className="flex items-center gap-2 px-5 py-2.5 text-sm font-semibold
                     bg-primary hover:bg-primary-dark text-white rounded-lg
                     transition-colors shadow-sm whitespace-nowrap flex-shrink-0"
        >
          <Plus size={15} />
          Add New Warehouse
        </button>
      </div>

      {/* ── Warehouses List card ── */}
      <div className="bg-white rounded-xl border border-surface-border overflow-hidden">
        {/* Card header */}
        <div className="px-5 py-4 border-b border-surface-border">
          <h2 className="text-xl font-bold text-primary-text font-display">
            Warehouses List
          </h2>
        </div>

        {/* Table */}
        <div className="px-5">
          <WarehouseTable
            warehouses={visibleWarehouses}
            loading={warehouseLoading}
            onToggleDefault={toggleDefault}
            onDetails={setDetailWarehouse}
            onEdit={openEditModal}
            onDelete={openDeleteModal}
          />
        </div>
      </div>

      {/* ── Add Warehouse Modal ── */}
      <AddWarehouseModal
        isOpen={showModal}
        form={form}
        errors={errors}
        saving={saving}
        onFormChange={handleFormChange}
        onAttributeChange={handleAttributeChange}
        onAdd={handleAdd}
        onClose={closeModal}
        title={editingWarehouse ? "Edit Warehouse" : "Add Warehouse"}
        submitLabel={editingWarehouse ? "Save" : "Add"}
      />

      <RecordDetailModal
        open={!!detailWarehouse}
        title="Warehouse Details"
        subtitle={detailWarehouse?.name}
        record={detailWarehouse}
        onClose={() => setDetailWarehouse(null)}
        fields={[
          { label: "Warehouse Name", key: "name" },
          { label: "Code", key: "code" },
          { label: "Attribute", key: "attribute" },
          { label: "Manager", key: "manager" },
          { label: "Phone", key: "phoneNumber" },
          { label: "Location", key: "location" },
          { label: "Country", key: "country" },
          { label: "Total SKU", key: "totalSku" },
          { label: "Default", key: "isDefault" },
          { label: "Status", key: "status" },
        ]}
      />

      <ConfirmActionModal
        open={deleteModal?.open}
        danger
        title="Delete Warehouse"
        loading={deleting}
        message={<>Delete <span className="font-semibold text-slate-800">{deleteModal?.warehouse?.name}</span>? This action cannot be undone.</>}
        confirmLabel="Delete"
        onCancel={closeDeleteModal}
        onConfirm={confirmDelete}
      />
    </div>
  );
}
