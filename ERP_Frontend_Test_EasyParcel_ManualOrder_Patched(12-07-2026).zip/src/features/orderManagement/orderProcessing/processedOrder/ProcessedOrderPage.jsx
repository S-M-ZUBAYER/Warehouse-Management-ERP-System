import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useNavigate, useNavigationType } from "react-router-dom";
import { toast } from "sonner";
import Topbar from "../../../../components/layout/Topbar";
import OrderProcessingFilterBar from "../../shared/components/OrderProcessingFilterBar";
import OrderTable from "../../shared/components/OrderTable";
import OrderFooter from "../../shared/components/OrderFooter";
import WaybillPrintModal from "../../shared/components/WaybillPrintModal";
import OrderActionModals from "../../shared/components/OrderActionModals";
import OrderDateRangePicker, { getPresetRange } from "../../shared/components/OrderDateRangePicker";
import ConfirmActionModal from "../../../../components/shared/ConfirmActionModal";
import { useOrderList } from "../../shared/hooks/useOrderList";
import { fetchProcessedOrderTabCounts, getStoredOrderListReturnState, setOrderDetailReturnContext } from "../../shared/utils/orderApi";
import { getDashboardOrderStatusFilter } from "../utils/dashboardOrderStatusFilter";

const SUB_TABS = ["Pushing", "Pushed Successful", "Withdraw"];

export default function ProcessedOrderPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const navigationType = useNavigationType();
  const dashboardFilter = useMemo(
    () => getDashboardOrderStatusFilter(location),
    [location.search, location.state]
  );
  const restoredPageState = useMemo(
    () => getStoredOrderListReturnState({ pathname: location.pathname, navigationType, pageType: "processed" }),
    [location.pathname, navigationType]
  );
  const [activeTab, setActiveTab] = useState(() =>
    SUB_TABS.includes(restoredPageState.activeTab)
      ? restoredPageState.activeTab
      : SUB_TABS.includes(dashboardFilter.tab)
        ? dashboardFilter.tab
        : "Pushing"
  );
  const [datePreset, setDatePreset] = useState(() => restoredPageState.datePreset || dashboardFilter.datePreset || "last_7_days");
  const [dateRange, setDateRange] = useState(() => restoredPageState.dateRange || dashboardFilter.dateRange || getPresetRange("last_7_days"));
  const [waybillOpen, setWaybillOpen] = useState(false);
  const [withdrawOrder, setWithdrawOrder] = useState(null);
  const [withdrawLoading, setWithdrawLoading] = useState(false);
  const list = useOrderList({ pageType: "processed", activeTab, datePreset, dateRange });
  const isWithdrawTab = activeTab === "Withdraw";
  const isPushingTab = activeTab === "Pushing";
  const isPushedSuccessfulTab = activeTab === "Pushed Successful";
  const isShopee = String(list.storeContext?.platform || "").toLowerCase().includes("shopee");
  const isTikTok = String(list.storeContext?.platform || "").toLowerCase().includes("tik");
  const shopeePrintLabel = isPushedSuccessfulTab ? "Print AWB Again" : "Push";
  const tikTokPrintLabel = isPushedSuccessfulTab ? "Print AWB Again" : "Push";
  const topActionName = isWithdrawTab ? "pack" : "push";
  const topActionLabel = isShopee && topActionName === "push" ? shopeePrintLabel : isTikTok && topActionName === "push" ? tikTokPrintLabel : isWithdrawTab ? "Pack" : "Push";
  const rowActionName = isWithdrawTab ? "pack" : "push";
  const rowActionLabel = isPushedSuccessfulTab ? "Print AWB Again" : isShopee && rowActionName === "push" ? shopeePrintLabel : isTikTok && rowActionName === "push" ? tikTokPrintLabel : isWithdrawTab ? "Pack" : "Push";
  const showTopActionButton = isWithdrawTab || !isShopee || topActionName !== "pack";
  const showRowActions = isPushedSuccessfulTab || isWithdrawTab || (isShopee || isTikTok ? rowActionName === "push" : !isPushedSuccessfulTab);
  const rowActions = isPushingTab
    ? [
        { label: rowActionLabel, onClick: (order) => list.runAction("push", [order]) },
        { label: "Withdraw", onClick: (order) => setWithdrawOrder(order) },
      ]
    : undefined;
  const {
    data: tabCounts = {},
    isLoading: tabCountsLoading,
    isFetching: tabCountsFetching,
  } = useQuery({
    queryKey: [
      "order-management",
      "processed-order-tab-counts",
      list.storeContext,
      list.appliedSearch,
      list.appliedSearchType,
      list.appliedSkuType,
      list.dateRange,
    ],
    queryFn: () =>
      fetchProcessedOrderTabCounts({
        context: list.storeContext,
        search: list.appliedSearch,
        searchType: list.appliedSearchType,
        skuType: list.appliedSkuType,
        dateRange: list.dateRange,
        tabs: SUB_TABS,
      }),
    enabled: list.hasStore,
    staleTime: 1000 * 60 * 30,
    gcTime: 1000 * 60 * 30,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
  });

  useEffect(() => {
    if (!restoredPageState.activeTab && SUB_TABS.includes(dashboardFilter.tab)) {
      setActiveTab(dashboardFilter.tab);
    }

    if (!restoredPageState.dateRange && dashboardFilter.dateRange) {
      setDatePreset(dashboardFilter.datePreset || "custom");
      setDateRange(dashboardFilter.dateRange);
    }
  }, [dashboardFilter, restoredPageState.activeTab, restoredPageState.dateRange]);

  const handleDetails = (order) => {
    list.cacheOrderForDetail(order);
    setOrderDetailReturnContext({
      fromPath: location.pathname,
      orderId: order.id,
    });
    navigate(`/warehouse_management/orders/detail/${encodeURIComponent(order.id)}`, {
      state: { order, fromPath: location.pathname, pageType: "processed", activeTab },
    });
  };

  const handleWaybillPrint = () => {
    if (!list.selectedRows.length) {
      toast.error("Please select at least one order to print waybill");
      return;
    }

    setWaybillOpen(true);
  };

  const handleConfirmWithdraw = async () => {
    if (!withdrawOrder) return;

    setWithdrawLoading(true);
    try {
      await list.markWithdraw([withdrawOrder]);
      setWithdrawOrder(null);
    } finally {
      setWithdrawLoading(false);
    }
  };

  return (
    <div className="space-y-4 font-body">
      <Topbar PageTitle="Order Processing" />
      <OrderProcessingFilterBar {...list} />

      <div className="bg-white rounded-xl border border-surface-border overflow-hidden">
        <div className="px-5 pt-5 pb-0">
          <div className="mb-4 flex items-center justify-between gap-4">
            <h2 className="text-xl font-bold text-slate-800 font-display">Processed Orders</h2>
            <OrderDateRangePicker
              datePreset={datePreset}
              setDatePreset={setDatePreset}
              dateRange={dateRange}
              setDateRange={setDateRange}
            />
          </div>

          {showTopActionButton && (
            <div className="mb-3">
              <button
                onClick={() => list.runAction(topActionName)}
                disabled={list.actionLoading}
                className="px-4 py-1.5 text-sm font-semibold border border-surface-border rounded-lg text-slate-700 bg-white hover:bg-surface-card transition-colors disabled:opacity-60"
              >
                {topActionLabel}
              </button>
            </div>
          )}

          <div className="flex items-center gap-5 border-b border-surface-border">
            {SUB_TABS.map((tab) => {
              const count = Number(tabCounts[tab] || 0);
              const hasWithdrawOrders = tab === "Withdraw" && count > 0;
              const isActive = activeTab === tab;
              const tabColor = hasWithdrawOrders ? "text-amber-600 hover:text-amber-700" : "text-slate-500 hover:text-slate-700";
              const activeColor = hasWithdrawOrders ? "text-amber-600 after:bg-amber-500" : "text-primary after:bg-primary";

              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-3 text-sm font-medium whitespace-nowrap transition-colors relative ${
                    isActive
                      ? `${activeColor} font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5`
                      : tabColor
                  }`}
                >
                  {tab} ({formatCount(tabCounts[tab], tabCountsLoading || tabCountsFetching)})
                </button>
              );
            })}
          </div>
        </div>

        <OrderTable
          orders={list.orders}
          loading={list.isLoading}
          isError={list.isError}
          selectedIds={list.selectedIds}
          onToggleSelect={list.toggleSelect}
          onToggleAll={list.toggleAll}
          allSelected={list.allSelected}
          pagination={list.pagination}
          page={list.page}
          setPage={list.setPage}
          showActionsCol={showRowActions}
          actionLabel={rowActionLabel}
          rowActions={rowActions}
          actionMenuPlacement="up"
          compact
          onAction={(order) => list.runAction(rowActionName, [order])}
          onDetails={handleDetails}
        />

        <OrderFooter selectedRows={list.selectedRows} onPrint={handleWaybillPrint} />
      </div>

      <WaybillPrintModal
        open={waybillOpen}
        orders={list.selectedRows}
        onClose={() => setWaybillOpen(false)}
      />

      <ConfirmActionModal
        open={!!withdrawOrder}
        title="Confirm Withdraw"
        message={
          <div className="space-y-2">
            <p>Are you sure you want to withdraw this order?</p>
            <p className="font-semibold text-slate-800">
              Order Number: {withdrawOrder?.orderNo || withdrawOrder?.id || "-"}
            </p>
          </div>
        }
        confirmLabel="Confirm"
        cancelLabel="Cancel"
        danger
        loading={withdrawLoading}
        onCancel={() => setWithdrawOrder(null)}
        onConfirm={handleConfirmWithdraw}
      />

      <OrderActionModals list={list} />
    </div>
  );
}

function formatCount(value, isLoading = false) {
  if (isLoading) return "_ _";

  const count = Number(value || 0);
  return String(Number.isFinite(count) ? count : 0).padStart(2, "0");
}
