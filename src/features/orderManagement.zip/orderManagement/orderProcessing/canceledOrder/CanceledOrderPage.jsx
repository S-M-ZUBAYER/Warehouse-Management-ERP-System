import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Topbar from "../../../../components/layout/Topbar";
import OrderProcessingFilterBar from "../../shared/components/OrderProcessingFilterBar";
import OrderTable from "../../shared/components/OrderTable";
import OrderFooter from "../../shared/components/OrderFooter";
import { useOrderList } from "../../shared/hooks/useOrderList";
import { MOCK_CANCELLED_ORDERS } from "../../shared/mockData";

const SUB_TABS = [
  { label: "All", count: 100 },
  { label: "Cancelation Request", count: "00" },
  { label: "Cancelled", count: 80 },
];

export default function CanceledOrder() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("All");
  const list = useOrderList(MOCK_CANCELLED_ORDERS);

  return (
    <div className="space-y-4 font-body">
      <Topbar PageTitle="Order Processing" />
      <OrderProcessingFilterBar {...list} />

      <div className="bg-white rounded-xl border border-surface-border overflow-hidden">
        <div className="px-5 pt-5 pb-0">
          <h2 className="text-xl font-bold text-slate-800 font-display mb-4">
            Cancelled Orders
          </h2>

          <div className="flex items-center gap-5 border-b border-surface-border">
            {SUB_TABS.map(({ label, count }) => (
              <button
                key={label}
                type="button"
                onClick={() => setActiveTab(label)}
                className={`pb-3 text-sm font-medium whitespace-nowrap transition-colors relative ${
                  activeTab === label
                    ? "text-primary font-semibold after:absolute after:bottom-0 after:left-0 after:right-0 after:h-0.5 after:bg-primary"
                    : "text-slate-500 hover:text-slate-700"
                }`}
              >
                {label} ({count})
              </button>
            ))}
          </div>
        </div>

        <OrderTable
          orders={list.orders}
          selectedIds={list.selectedIds}
          onToggleSelect={list.toggleSelect}
          onToggleAll={list.toggleAll}
          allSelected={list.allSelected}
          showActionsCol={false}
          compact
          onDetails={(order) =>
            navigate(`/warehouse_management/orders/detail/${order.id}`)
          }
        />

        <OrderFooter
          selectedRows={list.orders.filter((order) =>
            list.selectedIds.includes(order.id)
          )}
        />
      </div>
    </div>
  );
}
